#include "game/game_state.hpp"
namespace wormhole {
// Interface-only translation boundary.
}
