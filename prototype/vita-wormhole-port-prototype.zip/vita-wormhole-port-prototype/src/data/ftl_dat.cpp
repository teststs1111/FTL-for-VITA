#include "data/ftl_dat.hpp"

namespace wormhole {

bool FtlDat::open(const std::string& path) {
    path_ = path;
    // Archive parsing is intentionally the next isolated port slice.
    open_ = false;
    return false;
}

std::vector<std::uint8_t> FtlDat::readFile(const std::string&) const {
    return {};
}

}
