# Vita Wormhole Port Prototype

This is the initial C++ migration skeleton for Project Wormhole / Tachyon.

It deliberately does **not** contain FTL assets (`ftl.dat`, graphics, audio, etc.).
Those remain external user-owned data.

## Goal

Build the C++/Vita layer incrementally rather than trying to mechanically convert
all 224 Java/Kotlin source files at once.

Initial architecture:

- `game/`       game loop/state interfaces
- `render/`     renderer abstraction, later backed by VitaGL
- `platform/`   Vita input/filesystem/window lifecycle
- `data/`       `ftl.dat` reader boundary

## Current status

- C++17 host-compilable skeleton
- Main game loop/state boundary defined
- Renderer boundary defined
- Vita input boundary defined
- `ftl.dat` boundary defined
- No Vita SDK dependency yet, so this can be used to validate architecture first

## Next port slices

1. VitaGL renderer backend
2. PNG/texture loading
3. Vita controls/touch mapping
4. FTL data/BXML parser
5. Ship/layout/systems model
6. InGameState simulation
7. UI
8. audio
9. save/load
