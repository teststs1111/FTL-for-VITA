# Porting notes from Tachyon

## Repository inspection

The upstream Tachyon tree contains 224 source files below `xyz/znix/xftl`:
- 213 Kotlin
- 11 Java

Major groups:
- game: 36
- systems: 19
- hangar: 18
- crew: 14
- rendering: 13
- weapons: 13
- sys: 12
- math: 10
- devutil: 10
- UI: 14
- AI: 4

## Recommended conversion order

### Slice A — platform/rendering
Translate:
- `sys/GameContainer`
- `sys/Input`
- `rendering/Graphics`
- `rendering/Image`
- `rendering/Texture`
- `rendering/TextureLoader`

Target: a Vita screen that can load one PNG and render one sprite.

### Slice B — data
Translate:
- `FTLFile`
- `Datafile`
- `bxml/*`
- relevant JDOM access layer

Target: read `ftl.dat`, enumerate/extract the XML/image resources required by
the title screen.

### Slice C — game model
Translate the data-oriented classes first:
- `Ship`
- `layout/*`
- `systems/*`
- `weapons/*`
- `crew/*`
- `drones/*`
- `sector/*`

Target: construct a ship and run simulation without UI.

### Slice D — game state/UI
Translate:
- `game/InGameState`
- `game/MainGame`
- `ui/*`
- `game/PlayerShipUI`
- menus/hangar

Target: start a real run and interact with it.

### Slice E — audio/save/mods
Translate only after the playable core:
- `SoundManager`
- `OpenALStreamPlayer`
- savegame
- optional Slipstream/mod support

## Things intentionally excluded at first

- developer menu
- desktop process detection
- Swing file dialogs
- multiplayer
- desktop GLFW
- desktop OpenAL
- mod editor conveniences

These are not required for the first Vita gameplay milestone.

## Important finding

`MainGame` and `InGameState` are Java/Kotlin application logic, while the Android
port replaces the desktop LWJGL/Slick platform layer. Therefore the Vita effort
is a genuine engine migration rather than a thin Android-to-Vita wrapper.

The cleanest path is to preserve the *behavioral architecture* while translating
the core model into C++, and to keep Vita-specific code behind the same boundaries.
