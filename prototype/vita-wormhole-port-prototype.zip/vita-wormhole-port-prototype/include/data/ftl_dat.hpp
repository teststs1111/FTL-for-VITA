#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace wormhole {

class FtlDat {
public:
    bool open(const std::string& path);
    bool isOpen() const { return open_; }

    // Initial boundary only. BXML/resource extraction will be implemented
    // independently of the game simulation.
    std::vector<std::uint8_t> readFile(const std::string& name) const;

private:
    bool open_{false};
    std::string path_;
};

}
